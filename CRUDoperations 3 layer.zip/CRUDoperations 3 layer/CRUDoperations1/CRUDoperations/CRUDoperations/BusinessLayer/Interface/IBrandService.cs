﻿using CRUDoperations.Models;

namespace CRUDoperations.BusinessLayer.Interface
{
	public interface IBrandService
	{
		Task<IEnumerable<Brand>> GetAllAsync();
		Task<Brand?> GetByIdAsync(int id);
		Task AddAsync(Brand brand);
		Task UpdateAsync(Brand brand);
		Task DeleteAsync(int id);
	}
}
