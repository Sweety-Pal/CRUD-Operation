﻿
namespace CRUDoperations.Models
{
    public class Brand
    {
        public  int ID { get; set; }
        public  string? Name { get; set; }
        public string? Catrgory { get; set; }
        public int IsActive { get; set; }

       
    }
}
