﻿using CRUDoperations.BusinessLayer.Interface;
using CRUDoperations.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRUDoperations.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class BrandsController : ControllerBase
	{
		private readonly IBrandService _service;

		public BrandsController(IBrandService service)
		{
			_service = service;
		}

		[HttpGet]
		public async Task<IActionResult> GetAll()
		{
			var brands = await _service.GetAllAsync();
			return Ok(brands);
		}

		[HttpGet("{id}")]
		public async Task<IActionResult> GetById(int id)
		{
			var brand = await _service.GetByIdAsync(id);
			if (brand == null)
				return NotFound();

			return Ok(brand);
		}

		[HttpPost]
		public async Task<IActionResult> Add(Brand brand)
		{
			await _service.AddAsync(brand);
			return CreatedAtAction(nameof(GetById), new { id = brand.ID }, brand);
		}

		[HttpPut("{id}")]
		public async Task<IActionResult> Update(int id, Brand brand)
		{
			if (id != brand.ID)
				return BadRequest();

			await _service.UpdateAsync(brand);
			return NoContent();
		}

		[HttpDelete("{id}")]
		public async Task<IActionResult> Delete(int id)
		{
			await _service.DeleteAsync(id);
			return NoContent();
		}
	}
}
